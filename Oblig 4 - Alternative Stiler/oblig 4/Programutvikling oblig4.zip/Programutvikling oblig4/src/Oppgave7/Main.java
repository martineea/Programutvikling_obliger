package Oppgave7;

import java.util.function.BiFunction;

/* OPPGAVE 7

Metoden drawPixels itererer gjennom alle pixlene til bildet.
For hver pixel bruker den en funksjon som tar x og y posisjonen til pixelen som parameter.
Denne funksjonen returnerer en int-tabell med tre verdier:
første verdi for rødfargen (R), andre verdi for grønn (G), og tredje verdi for blå (B).
Den returnerer dermed en RGB farge som blir fargen til pixelen. RGB verdier er gyldige mellom 0 og 255.

Lag en main metode som bruker en referanse til et BiFunction objekt til å tegne et bilde.
Bruk deretter metoden writeImageToFile til å skrive ut bildet til en png bildefil.
Metoden under kan brukes som en BiFunction.
Den tegner en fargegradient mellom rød og blå.
Hvis du vil, kan du gjerne lage din egen tegnefunksjon.

*/


public class Main {
    
    public static int[] gradientRedBlue(int x, int y) {
            int[] grad = new int[3];
            grad[0] = (int) (x%256.0);
            grad[2] = (int) (y%256.0);
            return grad;
        }
    
    public static void main(String [] args){
        
        Image image1 = new Image(2000,1000);
        image1.drawPixels((a, b) -> gradientRedBlue(a,b));
        image1.writeImageToFile("/Users/Synne/Documents/bilde.png", "png");
        
        
        
    }
}
