package Oppgave3;

public class Main {
    
    public static void main (String [] args){
        
        StaticArrayList liste = new StaticArrayList(3);
        
        Integer tall1 = 5;
        Double tall2 = 2.2;
        Integer tall3 = 3;
        
        liste.add(tall1);
        liste.add(tall2);
        liste.add(tall3);
        
        System.out.println(liste.get(2));
        System.out.println(liste.size());
        
        
        
    }
    
}
