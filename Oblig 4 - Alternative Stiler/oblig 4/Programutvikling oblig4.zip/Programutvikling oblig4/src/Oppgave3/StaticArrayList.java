package Oppgave3;

import java.util.AbstractList;
import java.util.ArrayList;

public class StaticArrayList <T> extends AbstractList<T> {
    private Object[] data;
    private int count = 0;
    
    public StaticArrayList (int length){
        data = new Object[length];
    }
    
    @Override
    public boolean add(T element){
            if(count<data.length){  
                data[count] = element;
                count++;
                return true;
            }
        return false;  
    }
    
    @Override
    public T get(int indeks) throws IndexOutOfBoundsException {
        if (indeks < 0 || indeks > data.length){
                throw new IndexOutOfBoundsException("Error");
            }
        
        else{
            return (T) data[indeks];
        }
        
    }
    
    @Override
    public int size (){
        return count;
    }
    
   
}




