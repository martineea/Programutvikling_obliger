package Oppgave5;

import java.util.ArrayList;

/* OPPGAVE 5

Opprett en ArrayList med noen elementer.
Skriv ut elementene til konsollen ved å bruke forEach metoden og referanse til System.out::println
(dvs. forEach(System.out::println)).

*/

class Person{
    String name;
    
    public Person (String name){
        this.name = name;
    }
    
    @Override
    public String toString(){
        return name;
    }
}

public class Main {
    public static void main (String [] args){
        
        Person p1 = new Person("Per");
        Person p2 = new Person("Pål");
        Person p3 = new Person("Kari");
        
        ArrayList <Person> liste = new ArrayList<>();
        liste.add(p1);
        liste.add(p2);
        liste.add(p3);
        
        liste.forEach(System.out::println);
        
    }
}
