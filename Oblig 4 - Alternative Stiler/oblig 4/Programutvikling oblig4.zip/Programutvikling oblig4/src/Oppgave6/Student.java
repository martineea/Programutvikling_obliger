package Oppgave6;

/* OPPGAVE 6 

Opprett en Student klasse, der du selv velger datafelt.
Hvis du har en en Student-klasse fra tidligere oppgaver, kan du gjerne bruke denne.

Legg noen student-objekter inn i en ArrayList og skriv ut listen til konsoll etter to forskjellige sorteringsmetoder.
Du skal bruke lambda funksjoner slik at du slipper å lage egne Comparator klasser.
Se lysbilde 10 fra PowerPoint presentasjonen til funksjonell programmering for eksempel på hvordan dette gjøres
(Alternative stiler - funksjonell.pdfPreview the document).   */


public class Student {
    
    String name;
    int alder;

  
    
    public Student(String name, int alder){
        this.name = name;
        this.alder = alder;
    }
    
    @Override
    public String toString(){
        return "Navn: "+name+" Alder: "+alder;
    }
    
    
}
