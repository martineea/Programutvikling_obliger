package Oppgave6;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/* Legg noen student-objekter inn i en ArrayList og skriv ut listen til konsoll etter to forskjellige sorteringsmetoder.
Du skal bruke lambda funksjoner slik at du slipper å lage egne Comparator klasser.
Se lysbilde 10 fra PowerPoint presentasjonen til funksjonell programmering for eksempel på hvordan dette gjøres
(Alternative stiler - funksjonell.pdfPreview the document).  */

public class Main {
    public static void main (String [] args){
        
        Student stud1 = new Student("Pål",20);
        Student stud2 = new Student("Per",22);
        Student stud3 = new Student("Ola",23);
        
        ArrayList <Student> studenter = new ArrayList<>();
        
        studenter.add(stud1);
        studenter.add(stud2);
        studenter.add(stud3);
        
        Collections.sort(studenter,(s1,s2) -> s1.name.compareTo(s2.name));
        Collections.sort(studenter,(Comparator.comparing(s -> s.alder)));
        
        studenter.forEach(System.out::println);
        
        
    }
}
