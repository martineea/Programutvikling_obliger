package Oppgave1;

import java.util.ArrayList;

public class Main {
   
    public static void main (String [] args){
        
        /* OPPGAVE 1 
        En student i Java prøver å opprette en heltallsliste.
        Her kommer følgende feilmelding: type argument cannot be of primitive type.
        Endre koden under slik at den fungerer. Tips: kjenner du til Integer klassen? */
        
        ArrayList<Integer> heltallsliste = new ArrayList<>();
        heltallsliste.add(1);
        heltallsliste.add(2);
        heltallsliste.add(3);
        System.out.println(heltallsliste);
        
        
        
    }
}
