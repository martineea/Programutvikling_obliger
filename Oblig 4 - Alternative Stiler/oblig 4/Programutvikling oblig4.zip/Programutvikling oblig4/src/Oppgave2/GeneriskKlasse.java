package Oppgave2;

public class GeneriskKlasse <T> {
    /* OPPGAVE 2
        Opprett en generisk klasse med parameter T, med følgende datafelt:

        T[] array;
        Opprett en konstruktør som tar størrelsen til array-tabellen som parameter. Konstruktøren skal opprette et tabellobjekt slik:

        array = new T[num];
        Dette burde produsere en kompileringsfeil. Hva sier IDEen din om denne feilen?

        PS: denne feilen rettes opp i ved neste oppgave. */
    
    T[] array;
    
    public GeneriskKlasse (T [] array){
        this.array = new T[num];
    }
    
    /* cannot find symbol.
    symbol: variable num
    location: GeneriskKlasse <T>
    where T is a type-variable:
    T extends Object declared in class GeneriskKlasse.
    Generic array creation
    */
}
