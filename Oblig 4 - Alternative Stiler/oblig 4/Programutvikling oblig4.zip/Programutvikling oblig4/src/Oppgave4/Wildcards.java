package Oppgave4;

public class Wildcards {
   
    /* OPPGAVE 4
    Les om Wildcards fra lenken under og beskriv problemene de løser.
    https://docs.oracle.com/javase/tutorial/java/generics/wildcards.html (Links to an external site.) */
    
    /*  
    
    WILDCARDS
    ? er symbolet for wildcard i generisk programmering. Det representerer en ukjent type.
    Wildcard kan bli brukt i flere situasjoner som: type parameter, datafelt eller lokal variabel;
    noen ganger som return type.
    Wildcard er aldri brukt som type argument for en generisk metode kall, generiske klasse instansiering eller som supertype.

    Ulikt med arrays, forskjellige instanser av generiske typer er ikke kompatible med hverandre.
    Derfor kan man bruke wildcard som en type parameter for å løse dette problemet. 

Ulike type wildcars
1.	Upper Bounded Wildcards: Kan brukes når man vil mykne restriksjonene på en varibel.
    For eks. om man har en metode som skal funke på List <Integer>, List <Double> og List <Number>,
    da kan man bruke en upper bounded wildcard. For å bruke denne skriver man (List<? Extends number> list).
    Altså ? etterfulgt av extends nøkkelordet, etterfulgt av dens «upper bound».
2.  Lower Bounded Wildcards: Er uttrykt ved ?, etterfulgt av super nøkkelordet, etterulgt av dens «lower bound».
    Syntaks: Collectiontype <? super A>

3.	Unbounded Wildcard: Hvis man skal lage en liste med ukjent type kan dette brukes.
        Kan være nyttige i følgende situasjoner: 
i.	Når man lager en metode som kan benyttes ved hjelp av funksjonalitet som tilbys i Objectklassen.
ii.	Når koden bruker metoder i generisk klasse som ikke er avhengig av typen parameter. 
    
For eks. ved koden under, der man skal printe ut en liste med objekter.
	public static void printList(List<Object> list) {
    		for (Object elem : list)
        		System.out.println(elem + " ");
    		System.out.println();
	}

Dersom man skal printe ut en Integer for eks, vil ikke denne koden fungere. Da Integer ikke er et type Object.
    For å kunne printe ut alle slags typer kan man heller skrive følgende kode:
	public static void printList(List<?> list) {
    		for (Object elem: list)
        		System.out.print(elem + " ");
    		System.out.println();
	}


    
    
    */
    
    
    
}
