
package Oppgave7;


public class Main {
    
    public static void main (String [] args){
    
        String[] strings = new String[6]; //array av type String med 6 plasser
        for(int i = 0; i < strings.length; i += 2) {  //løkke som løper gjennom arrayet, men hopper over 1 hver gang
            strings[i] = "This is string number " + (i/2+1);  //Skriver at string[0]= 1, string[2]=2, string[4]=3.
        }

        for(String str : strings) { //løper igjennom arrayet på nytt
            try {                       
                if (str.isEmpty()) {    //hvis et element er tomt skriver den ut melding
                System.out.println("This string is empty"); 
                }

            System.out.println(str + " ");  //hvis ikke skriver den ut elementet
            }
            catch (NullPointerException e) {} //catcher NullPointerException, ikke riktig
        }

    
    
 // Ved å catche NullPointerException så vil programmet kjøre, men bugen er det fortsatt.
 // Man skal ikke bruke avvik til kontrollstrukturer.
 // Man skal ikke håndtere avvik på denne måten av to grunner: lesbarhet og at bugen fortsatt er der.
 // NullPointerException er et unchecked avvik og en programmeringsfeil i dette tilfellet.
 
 //Løsning: inne i forløkken ha en if(str != null)
 //Løsning: endre arrayet til en ArrayList, da unngår man nullpeker problematikken! 
    
    }
}
