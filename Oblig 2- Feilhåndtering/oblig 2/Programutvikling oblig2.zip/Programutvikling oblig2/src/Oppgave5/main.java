
package Oppgave5;

import static javax.swing.JOptionPane.*;

/* 
Input: a and b integers (int), both integers must be positive,
since the calculation does not support negative numbers.

Result: the largest number that can be divided by a and b and produce an integer number.

*/

public class main {
    
    public static int eukildsAlgoritme (int a, int b) throws InvalidInputException{
        if(a < 0 || b < 0){
            throw new InvalidInputException("Tallet kan ikke være negativt");
        }
        
        while( a != b ) {
        if (a > b) {
            a = a - b;
        } else {
         b = b - a;
        }
    }
        assert (checkDivision(a,b));
        return a;
    }
    
    public static boolean checkDivision(int a, int b) {
        return a % b == 0;
    }
    
    public static void main(String [] args) throws InvalidInputException{
       
        String innstring1 = showInputDialog("Skriv inn et tall");
        String innstring2 = showInputDialog("Skriv inn et tall");
        
        try {
            int tall1 = Integer.parseInt(innstring1);
            int tall2 = Integer.parseInt(innstring2);
        
            showMessageDialog(null, eukildsAlgoritme(tall1, tall2));
        }
        catch (InvalidInputException e){
            showMessageDialog(null, e.getMessage());
        }  
    }
    
}
