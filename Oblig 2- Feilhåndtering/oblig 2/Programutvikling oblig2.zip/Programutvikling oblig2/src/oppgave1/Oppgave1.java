
package oppgave1;

/* Oppgave 1
Koden under sjekker om en epost er en korrekt student-epost til OsloMet.
Beskriv hensikten med hver sjekk.
Se i Java sin dokumentasjon for String hvis det er noen metoder du ikke kjenner til.*/

public class Oppgave1 {
    
   public static int checkValidOsloMetMail(String email) {
        String[] splitStrAlpha = email.split("@");
        if (splitStrAlpha.length != 2)
            return -1; // ERROR CODE 1: string is not a valid email
        
        //Hensikten med denne sjekken: Det er for å sjekke at det er skrevet inn både før og etter @ og feilkoden -1 blir returnert.

        if(!splitStrAlpha[1].equals("oslomet.no")) {
            return -2; // ERROR CODE 2: string is not a valid OsloMet email
        }
        
        //Hensikten med denne sjekken: Hvis mailen ikke inneholder stringen "oslomet.no" så er det ikke en gyldig oslomet mail og feilkoden -2 blir returnert.

        String studentStr = splitStrAlpha[0];
        if(studentStr.length() != 7 || studentStr.charAt(0) != 's') {
            return -3; // ERROR CODE 3: email is not a valid student OsloMet email
        }
        
        //Hensikten med denne sjekken: studentStr.length sjekker at studentnummeret består av 7 tegn og det må begynne på s(charAt(0)).

        // check if the six numbers behind "s" are valid numbers
        try {
            int testInt = Integer.parseInt(studentStr.substring(1));
            if(testInt < 0)
                return -3; // no negative numbers in student numbers
        } catch(NumberFormatException e) {
            return -3;
        }

        return 0; // email is valid

        //Sjekker at det ikke er negative tall skrevet inn.
    }   

   

//Denne metoden sjekker de forskjellige feilkodene som blir returnert fra metoden over og printer ut evt. riktig error melding.   
public static void checkMail(String email) {
    int testMail = checkValidOsloMetMail(email);

    if(testMail == -1) {
        System.err.println(email + " is not a valid email");
    }
    else if (testMail == -2) {
        System.err.println(email + " is not a valid OsloMet email");
    }
    else if (testMail == -3) {
        System.err.println(email + " is not a valid OsloMet student email");
    }
    else {
        System.out.println("Hello student with id " + email.split("@")[0]);
    }
}

public static void main(String[] args) {
    String email1 = "s123456@hioa.no";
    String email2 = "s123456@oslomet.no";
    String email3 = "henrik.lieng@oslomet.no";
    String email4 = "so_bad!@oslomet.no";
    String email5 = "thisIsNoEMail";

    checkMail(email1);
    checkMail(email2);
    checkMail(email3);
    checkMail(email4);
    checkMail(email5);
    }
    
    
}
