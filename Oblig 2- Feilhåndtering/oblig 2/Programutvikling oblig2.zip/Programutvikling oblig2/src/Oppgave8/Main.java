package Oppgave8;

public class Main {
    
/* Finally-blokka garanterer at kode kjøres, selv om et unntak inntreffer.
Følgende spørsmål er et JA/NEI spørsmål.
Ved eksperimentering, test om kode i finally blokka kjøres selv om man har et
return-kall i try-blokka og ingen unntak inntreffer
(dvs. at return inntreffer i try). */
    
// Ja! Finally vil alltid bli utført og har høyere prioritet enn return
    
    
}
