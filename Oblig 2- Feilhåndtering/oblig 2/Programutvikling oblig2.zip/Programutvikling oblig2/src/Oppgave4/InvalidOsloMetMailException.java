package Oppgave4;



public class InvalidOsloMetMailException extends InvalidEmailException {
    
    public InvalidOsloMetMailException(String mld){
     super(mld);
  }
}
