package Oppgave4;



public class InvalidEmailException extends Exception {
    
    public InvalidEmailException (String mld){
        super(mld);
        
    }
}

