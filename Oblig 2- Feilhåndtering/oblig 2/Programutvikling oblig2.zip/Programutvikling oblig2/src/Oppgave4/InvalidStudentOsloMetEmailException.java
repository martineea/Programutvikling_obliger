package Oppgave4;


public class InvalidStudentOsloMetEmailException extends InvalidOsloMetMailException{  
   
   public InvalidStudentOsloMetEmailException(String mld){
     super(mld);
  }
    
}
