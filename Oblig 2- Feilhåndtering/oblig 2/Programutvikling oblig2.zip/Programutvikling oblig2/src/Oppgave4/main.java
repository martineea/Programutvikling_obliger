
package Oppgave4;


public class main {

public static int checkValidOsloMetMail(String email) throws InvalidEmailException {
    String[] splitStrAlpha = email.split("@");
    if (splitStrAlpha.length != 2){
        throw new InvalidEmailException (email + " is not a valid email"); 
    }
    

    if(!splitStrAlpha[1].equals("oslomet.no")) {
        throw new InvalidOsloMetMailException(email + " is not a valid OsloMet email");
    }

    String studentStr = splitStrAlpha[0];
    if(studentStr.length() != 7 || studentStr.charAt(0) != 's') {
        throw new InvalidStudentOsloMetEmailException(email + " is not a valid OsloMet student email");
    }

    // check if the six numbers behind "s" are valid numbers
    try {
        int testInt = Integer.parseInt(studentStr.substring(1));
        if(testInt < 0)
            return -3; // no negative numbers in student numbers
    } catch(NumberFormatException e) {
        return -3;
    }

    return 0; // email is valid

}    

public static void checkMail(String email) throws InvalidEmailException {
    int testMail = checkValidOsloMetMail(email);   
    
    try {
        checkValidOsloMetMail(email);
        System.out.println("Hello student with id " + email.split("@")[0]);
    }
    catch (InvalidStudentOsloMetEmailException e){
        System.err.println(e.getMessage());
    }
    catch (InvalidOsloMetMailException f){
        System.err.println(f.getMessage());
    }
    catch(InvalidEmailException g){
        System.err.println(g.getMessage());
    }
   
}

public static void main(String[] args) throws InvalidEmailException {
 String email1 = "s123456@hioa.no";
 String email2 = "s123456@oslomet.no";
 String email3 = "henrik.lieng@oslomet.no";
 String email4 = "so_bad!@oslomet.no";
 String email5 = "thisIsNoEMail";

 checkMail(email1);
 checkMail(email2);
 checkMail(email3);
 checkMail(email4);
 checkMail(email5);
}
    
}
