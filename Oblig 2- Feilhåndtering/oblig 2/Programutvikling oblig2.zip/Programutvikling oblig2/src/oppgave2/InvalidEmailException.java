package oppgave2;

public class InvalidEmailException extends Exception {
    
    public InvalidEmailException (String mld){
        super(mld);
        
    }
}

