package oppgave2;

public class InvalidOsloMetMailException extends InvalidEmailException {
    
    public InvalidOsloMetMailException(String mld){
     super(mld);
  }
}
