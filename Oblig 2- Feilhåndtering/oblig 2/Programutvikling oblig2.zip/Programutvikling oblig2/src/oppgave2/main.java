
package oppgave2;

/* Oppgave 2
Du skal nå endre koden over til å bruke avvik istedenfor å bruke feilkoder.
Først, opprett følgende avviksklasser:

InvalidEmailException extends Exception
InvalidOsloMetEmailException extends InvalidEmailException
InvalidStudentOsloMetEmailException extends InvalidOsloMetEmailException

&&

Oppgave 3
Konverter koden i metoden checkValidOsloMetMail til å bruke de tre avvikene du har laget.
Kast det avviket som passer for feilen med en beskrivende feilmelding i konstruktøren.
Siden alle avvikene er samlet i et arvehierarki,
trenger du bare å deklarere metoden med "throws InvalidEmailException".
InvalidEmailException brukes fordi det er dette avviket som ligger øverst i hierarkiet.
Du kan midlertidig håndtere avvikene i den kallende metoden (checkMail)
ved å kaste avviket videre i både checkMail og i main metoden.
Hvis dette avviket nå inntreffer burde Javaprogrammet krasje med
beskrivelse for avviket skrevet ut til konsollen.


*/


public class main {

public static int checkValidOsloMetMail(String email) throws InvalidEmailException {
    String[] splitStrAlpha = email.split("@");
    if (splitStrAlpha.length != 2){
        throw new InvalidEmailException ("String is not a valid email"); 
    }
    

    if(!splitStrAlpha[1].equals("oslomet.no")) {
        throw new InvalidOsloMetMailException("String is not a valid OsloMet email");
    }

    String studentStr = splitStrAlpha[0];
    if(studentStr.length() != 7 || studentStr.charAt(0) != 's') {
        throw new InvalidStudentOsloMetEmailException("email is not a valid student OsloMet email");
    }

    // check if the six numbers behind "s" are valid numbers
    try {
        int testInt = Integer.parseInt(studentStr.substring(1));
        if(testInt < 0)
            return -3; // no negative numbers in student numbers
    } catch(NumberFormatException e) {
        return -3;
    }

    return 0; // email is valid

}    

public static void checkMail(String email) throws InvalidEmailException {
    int testMail = checkValidOsloMetMail(email);   
}

public static void main(String[] args) throws InvalidEmailException {
 String email1 = "s123456@hioa.no";
 String email2 = "s123456@oslomet.no";
 String email3 = "henrik.lieng@oslomet.no";
 String email4 = "so_bad!@oslomet.no";
 String email5 = "thisIsNoEMail";

 checkMail(email1);
 checkMail(email2);
 checkMail(email3);
 checkMail(email4);
 checkMail(email5);
}
    
}
