package programutvikling.oblig;


public class GradeComparator implements Comparable<StudentGroup> {

    @Override
    public int compareTo(StudentGroup o) {
        
    }

    
    
    
}
